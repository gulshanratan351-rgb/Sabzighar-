import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import App from './App.jsx';
import { AuthProvider } from './context/AuthContext.jsx';
import './styles.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <div className="app-shell">
          <App />
          <Toaster position="top-center" toastOptions={{ style: { fontSize: 14 } }} />
        </div>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);
